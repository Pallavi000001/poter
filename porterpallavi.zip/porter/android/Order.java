port 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Order extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return Ordere();
  }
}
class Ordere extends State<Order> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
      child: Scaffold(