package com.example.porter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
