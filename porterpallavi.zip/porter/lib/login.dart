import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:porter/color/AppColors.dart';

class Login extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return Loginn();
  }
}
class Loginn extends State<Login> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor:AppColors.white ,
          iconTheme: IconThemeData(color: Colors.black),
        ),
    body: SingleChildScrollView(
      child: Container(
      child: Column(

          children: [
      Center(
        child: Container(
          padding: EdgeInsets.only(top: 80),
          height: 200,
          child:Column(
        children: [
          Container(
            child: Text("Let's Get Started!",
            style: TextStyle(
              fontSize: 25,
              color: AppColors.black,
              fontWeight: FontWeight.bold

            ),
            ),
          ),
         // width: MediaQuery.of(context).size.width,
//color: Colors.white,
    //    ),
          Container(
            padding: EdgeInsets.only(top: 10),
            child: Text("Create an account to Q Allure to get all features",
            style: TextStyle(
              fontSize:
                16
            ),
            ),
          ),
              ]
        ),),
      ),
            Container(
              padding: EdgeInsets.only(top: 20,bottom: 5),
              child: Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10.0),
                    child: Container(
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            border: Border.all(color: Colors.black12)),
                        child: Row(
                          children: [
                            Container(
                              padding: EdgeInsets.only(left: 20),
                              child: Icon(Icons.perm_identity_outlined,
                              color: AppColors.redcolor3,
                              ),
                            ),
                            Container(
                              width: 250,
                              child: TextField(
                                autofocus: true,
                                //controller: category_description,
                                decoration: InputDecoration(
                                    border: InputBorder.none,
                                    hintText:"Name",
                                    hintStyle:
                                    TextStyle(color: AppColors.redcolor3),
                                    contentPadding: EdgeInsets.only(
                                      left: 10,
                                    ),
                                    counterText: ""),
                                keyboardType: TextInputType.text,
                                maxLength: 10,
                              ),
                            ),
                          ],
                        )),
                  ),
                  SizedBox(
                    height: 10.0,
                  ),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.only(top: 10),
              child: Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10.0),
                    child: Container(
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            border: Border.all(color: Colors.black12)),
                        child: Row(
                          children: [
                            Container(
                              padding: EdgeInsets.only(left: 20),
                              child: Icon(Icons.inbox_outlined,
                                color: AppColors.redcolor3,
                              ),
                            ),
                            Container(
                              width: 250,
                              child: TextField(
                                autofocus: true,
                                //controller: category_description,
                                decoration: InputDecoration(
                                    border: InputBorder.none,
                                    hintText:"Email",
                                    hintStyle:
                                    TextStyle(color: AppColors.redcolor3),
                                    contentPadding: EdgeInsets.only(
                                      left: 10,
                                    ),
                                    counterText: ""),
                                keyboardType: TextInputType.text,
                                maxLength: 10,
                              ),
                            ),
                          ],
                        )),
                  ),
                  SizedBox(
                    height: 5.0,
                  ),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.only(top: 20),
              child: Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10.0),
                    child: Container(
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            border: Border.all(color: Colors.black12)),
                        child: Row(
                          children: [
                            Container(
                              padding: EdgeInsets.only(left: 20),
                              child: Icon(Icons.phone,
                                color: AppColors.redcolor3,
                              ),
                            ),
                            Container(
                              width: 250,
                              child: TextField(
                                autofocus: true,
                                //controller: category_description,
                                decoration: InputDecoration(
                                    border: InputBorder.none,
                                    hintText:"Phone ",
                                    hintStyle:
                                    TextStyle(color: AppColors.redcolor3),
                                    contentPadding: EdgeInsets.only(
                                      left: 10,
                                    ),
                                    counterText: ""),
                                keyboardType: TextInputType.text,
                                maxLength: 10,
                              ),
                            ),
                          ],
                        )),
                  ),
                  SizedBox(
                    height: 10.0,
                  ),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.only(top:20),
              child:  Row(
                children: [
                  Row(
                    children: <Widget>[
                      Radio(
                        value: 'Female',
                        // groupValue: _radioValue,
                        // onChanged: radioButtonChanges,
                      ),
                      Text(
                        "Female",
                      ),
                    ],
                  ),
                  Row(
                    children: <Widget>[
                      Radio(
                        value: 'Female',
                        // groupValue: _radioValue,
                        // onChanged: radioButtonChanges,
                      ),
                      Text(
                        "Male",
                      ),
                    ],
                  ),
                ],
              ),

            ),
            Container(
              padding: EdgeInsets.only(top: 20,left: 20,right: 20),
              width:MediaQuery.of(context).size.width,
              child:
            RaisedButton(
              //  padding: EdgeInsets.only(right: 20, left: 20),

              //// shape: Border.all(width: 2.0),
              shape: StadiumBorder(),
              color: AppColors.segcolor4,

              onPressed: () {
              //  Navigator.push(context, SlideTopRoute(page: Login()));
              },
              child: Text("CREATE",
                  style: TextStyle(
                    fontSize: 15,
                    color: Colors.white,
                  )),

              //textColor: Colors.blue,
            ),
            ),
            Container(
              padding: EdgeInsets.only(left: 40,top: 20),
              child:Row(
                children: [
                  Container(
              child: Text("Already have an account?"),
            ),
                  Container(
                  child: FlatButton(
                      onPressed: (){
                      },

                      child: Text("Login here ",style: TextStyle(fontSize: 15,color:AppColors.redcolor3,))


                    // textColor: Colors.blue,

                  ),
                  ),
        ])),

]
              ),
      ),
    )
    ),
      );

  }
}