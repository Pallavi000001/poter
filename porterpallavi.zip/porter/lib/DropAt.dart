import 'dart:async';
//import 'dart:html';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'package:porter/choose%20location.dart';
import 'package:porter/color/AppColors.dart';
import 'navanimator/navianimator.dart';

class Dropat extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return Dropatt();
  }
}

class Dropatt extends State<Dropat> {
  Location location = new Location();
  bool _serviceEnabled;
  PermissionStatus _permissionGranted;
  LocationData _locationData;
  var lat = 0.0;
  var lng = 0.0;
  getLocation() async {
    _permissionGranted = await location.hasPermission();
    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != PermissionStatus.granted) {}
    }

    _serviceEnabled = await location.serviceEnabled();
    if (!_serviceEnabled) {
      _serviceEnabled = await location.requestService();
    } else {
      _locationData = await location.getLocation();
      setState(() {
        lat = _locationData.latitude;
        lng = _locationData.longitude;
        print(lat);
      });
      if (!_serviceEnabled) {
        return;
      }
    }
  }

  Completer<GoogleMapController> _controller = Completer();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getLocation();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
        backgroundColor:AppColors.white ,
        iconTheme: IconThemeData(color: Colors.black),
        title: Text(
          "Drop at",
          style: new TextStyle(
            fontWeight: FontWeight.bold,
             color: Colors.black,
            fontSize: 20,
          ),
        ),
      ),
      body: Container(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
                padding: EdgeInsets.only(top: 10),
                child: Row(
                  children: [
                    Container(
                        padding: EdgeInsets.only(left: 10),
                        height: 25,
                        width: 25,
                        child: Image.asset("assets/red icon.png")),
                    Container(
                      // height: 100,

                      //color: Colors.white,

                      child: Column(
                        children: <Widget>[
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 10.0),
                            child: Container(
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(10)),
                                    border: Border.all(color: Colors.black12)),
                                child: Row(
                                  children: [
                                    Container(
                                      width: 300,
                                      //height: 50,

                                      child: TextField(
                                        // autofocus: true,
                                        //controller: category_description,
                                        decoration: InputDecoration(
                                            border: InputBorder.none,
                                            hintText: "Searching.......",
                                            hintStyle: TextStyle(
                                                color: Colors.grey[400]),
                                            contentPadding: EdgeInsets.only(
                                              left: 10,
                                            ),
                                            counterText: ""),
                                        keyboardType: TextInputType.text,
                                        maxLength: 10,
                                      ),
                                    ),
                                  ],
                                )),
                          ),
                          SizedBox(
                            height: 10.0,
                          ),
                        ],
                      ),
                    ),
                  ],
                )),
          ),
          Expanded(
            child: lat == 0.0
                ? Container()
                : Stack(children: [
                    GoogleMap(
                      // mapType: MapType.normal,
                      // polylines: poly,
                      initialCameraPosition:
                          CameraPosition(target: LatLng(lat, lng), zoom: 15.0),
                      onMapCreated: (GoogleMapController controller) {
                        _controller.complete(controller);
                      },
                      compassEnabled: true,
                      //mapToolbarEnabled: false,
                      // zoomGesturesEnabled: true,
                      myLocationButtonEnabled: true,
                      zoomControlsEnabled: false,

                      // circles: circles,
                      myLocationEnabled: true,
                      padding: EdgeInsets.only(
                          top: MediaQuery.of(context).size.height / 2),
                      // markers: Set.from(allMarks),
                      onCameraIdle: () {
                        // print(_lastMapPosition);
                        // getCurrentLocation(_lastMapPosition.latitude,
                        //     _lastMapPosition.longitude);
                      },
                      onCameraMove: (CameraPosition position) {
                        // print(position.target);
                        setState(() {
                          // _lastMapPosition = position.target;
                          lat = position.target.latitude;
                          lng = position.target.longitude;
                        });
                        // getCurrentLocation(
                        //     _lastMapPosition.latitude, _lastMapPosition.longitude);
                      },
                    ),
                  ]),

          ),
          Center(
            child: Container(
              width: 300,
              child: FlatButton(
                padding: EdgeInsets.only(right: 30,left: 30,),
                minWidth: 30,
                //// shape: Border.all(width: 2.0),
                shape: StadiumBorder(),
                color: AppColors.redcolor3,

                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>TopSnapSheetExample()));
                },
                child: Text("Choose location",
                    style: TextStyle(fontSize: 18,color: Colors.white,))
                ,
                // textColor: Colors.blue,

              ),



            ),
          ),
        ]),
      ),
    ));
  }
}
