import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:porter/color/AppColors.dart';
import 'package:porter/edit.dart';
import 'package:porter/login.dart';

import 'navanimator/navianimator.dart';
import 'offer.dart';

class Account extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return Accountt();
  }
}

class Accountt extends State<Account> {
  var viewdetail = false;

  setViewDetail() async {
    if (viewdetail == false) {
      setState(() {
        viewdetail = true;
      });
    } else {
      setState(() {
        viewdetail = false;
      });
    }
  }

  var hidedtails = true;
  setViewDetails() async {
    if (hidedtails == true) {
      setState(() {
        viewdetail = false;
      });
    } else {
      setState(() {
        viewdetail = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
        child: Scaffold(
      body: Container(
          //padding: EdgeInsets.only(left: 10),
          child: ListView(children: [
        Container(
          padding: EdgeInsets.only(top: 10, left: 10),
          child: Text(
            "Name Xyzzzz",
            style: TextStyle(
              color: AppColors.black,
              fontSize: 25,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        Container(
          child: Row(children: [
            Container(
              padding: EdgeInsets.only(top: 5, left: 12),
              child: Text(
                "7667023445",
                style: TextStyle(
                  fontSize: 20,
                  //fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.only(top: 6),
              child: IconButton(
                icon: Icon(
                  Icons.check_circle,
                  size: 20,
                  color: AppColors.redcolor3,
                ),
              ),
            )
          ]),
        ),
        Container(
        // padding: EdgeInsets.only(top: 15, left: 13, bottom: 15),
          child: viewdetail == false
              ? InkWell(
                  onTap: () {
                    setViewDetail();
                  },
                  child:
                  Container(
                    padding: EdgeInsets.only(left: 13,bottom: 10),
                    child: Text("View Details",
                        style: TextStyle(
                          fontSize: 20,
                          color: AppColors.redcolor3,
                        )),
                  ),
                )
              : Container(
            child: ListTile(
              title: Text("plvkmri05@gmail.com",
                  style: TextStyle(
                    color: Colors.black,
                  )),
              subtitle: Text("Unverified",
                  style: TextStyle(
                    color: Colors.red,
                  )),
              trailing: FlatButton(
                padding: EdgeInsets.only(right: 20, left: 20),
                minWidth: 20,
                shape: Border.all(
                    width: 2.0,
                    // shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)),
                    color: Colors.green),

                color: Colors.green.shade50,

                onPressed: () {
                  //   Navigator.push(context, Signup);
                },
                child: Text(
                  "Varify",
                  style: TextStyle(
                    fontSize: 15,
                    color: Colors.green,
                  ),
                ),

                //textColor: Colors.blue,
              ),
            ),

            // padding: EdgeInsets.only(left: 5),

                ),
        ),
        //Container(
        //     child: Column(
        //       children: [
        //         Row(
        //           children: [
        //             Container(
        //               child: Column(
        //                 crossAxisAlignment: CrossAxisAlignment.start,
        //                 children: [
        //                   Container(
        //                     child: Text("plvkmri05@gmail.com",
        //                         style: TextStyle(
        //                           color: Colors.black,
        //                         )),
        //                   ),
        //                   Container(
        //                     padding: EdgeInsets.only(top: 10),
        //                     child: Text("Unverified",
        //                         style: TextStyle(
        //                           color: Colors.red,
        //                         )),
        //                   )
        //                 ],
        //               ),
        //             ),
        //             Container(
        //               padding: EdgeInsets.only(left: 140),
        //               //width: MediaQuery.of(context).size.width,
        //               // width: MediaQuery.of(),
        //               child: FlatButton(
        //                 padding: EdgeInsets.only(right: 20, left: 20),
        //                 minWidth: 20,
        //                 shape: Border.all(
        //                     width: 2.0,
        //                     // shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)),
        //                     color: Colors.green),
        //
        //                 color: Colors.green.shade50,
        //
        //                 onPressed: () {
        //                   //   Navigator.push(context, Signup);
        //                 },
        //                 child: Text("Varify",
        //                     style: TextStyle(
        //                       fontSize: 15,
        //                       color: Colors.green,
        //                     )),
        //
        //                 //textColor: Colors.blue,
        //               ),
        //             )
        //           ],
        //  ),
        // Container(
        //   //padding: EdgeInsets.only(bottom: 10, left: 10),
        //   child: Text(
        //     "GST details not available",
        //     style: TextStyle(color: Colors.black26),
        //   ),
        // ),
        // Container(
        //   padding: EdgeInsets.only(top: 10, bottom: 10),
        //   child: Container(
        //     padding: EdgeInsets.only(bottom: 10),
        //     height: 2,
        //     color: Colors.black38,
        //   ),
        // ),
            Container(
              child: viewdetail == true?

              InkWell(
                onTap: () {
                  setViewDetail();
                },

                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: EdgeInsets.only(left: 15),
                      child: Text(
                        "GST details not available",
                        style: TextStyle(color: Colors.black26),
                      ),
                    ),
                    Container(
                     padding: EdgeInsets.only(top: 10),
                      child: Container(
                        padding: EdgeInsets.only(bottom: 10),
                        height: 2,
                        color: Colors.black38,
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                            padding: EdgeInsets.only(top: 10, left: 14, bottom: 15),
                            child:    Text("Hide Details",
                style: TextStyle(
                  fontSize: 20,
                  color: AppColors.redcolor3,
                )),


                    ),

                        Container(
                          padding: EdgeInsets.only(right: 10),
                          child: Container(
                             // padding: EdgeInsets.only(
                             //   right: 10
                             // ),
                            height: 35,
                            width: 100,

                            decoration: BoxDecoration(
                              border: Border.all(
                                color:AppColors.segcolor4
                              ),
                              color:AppColors.segcolor4,
                              borderRadius: BorderRadius.all(Radius.circular(120))
                            ),
                            child:
                            InkWell(
                              onTap: ()
                              {
                                Navigator.push(context, MaterialPageRoute(builder: (context)=>Edit()));
                              },
                              child: Center(
                                child: Text("Edit",

                                    style: TextStyle(
                                      fontSize: 18,
                                      color: Colors.white,
                                    ),textAlign: TextAlign.center,
                                ),
                              ),
                            ),
                          ),
                        )

                  ],
                ),
              ]
              )
            ):  Container()),
        Container(
          padding: EdgeInsets.only(bottom: 10, top: 10),
          height: 8,
          color: Colors.black12,
        ),
        Container(
          padding: EdgeInsets.only(bottom: 20, top: 10),
          height: 200,
          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(
            //color: AppColors.primary,
              borderRadius: BorderRadius
                  .all(
                  Radius.circular(1)),
              image: DecorationImage(
                  image: NetworkImage("https://res.klook.com/image/upload/fl_lossy.progressive,q_85/c_fill,w_204,h_156/US_MKT_International_Friendship_Day_1200x630_v2_fz5l2n.jpg"
                     ),
                  fit: BoxFit.cover)),
                
          ),
        Container(
          
          padding: EdgeInsets.only(left: 15,top: 10),
          child: Text(
            "Invite friends",
            style: TextStyle(
              color: AppColors.redcolor3,
              fontSize: 20,
             // fontWeight: FontWeight.bold,
            ),
          ),
        ),
        Container(
          child: ListTile(
              title: Text("If you love what we are doing,"),
              subtitle: Text("Please spread the word!"),
              trailing: Container(
                //height: 40,
                width: 100,
                child: RaisedButton(
                  //   padding: EdgeInsets.only(right:5,left: 100),
                  //minWidth: 2,
                  //shape: Border.all(width: 2.0),
                  shape: StadiumBorder(),
                  color: AppColors.segcolor4,

                  onPressed: () {
                    //   Navigator.push(context, Signup);
                  },
                  child: Row(
                    children: [
                      Icon(
                        Icons.share,
                        color: Colors.white,
                      ),
                      Container(
                        child: Text("Invite",
                            style: TextStyle(
                              fontSize: 15,
                              color: Colors.white,
                            )),
                      ),
                    ],
                  ),
                ),
              )),
        ),

        Container(
          height: 8,
          color: Colors.black12,
        ),

        Container(
          child: ListTile(
            title: Text(
              "Contact Us",
              style: TextStyle(
                color: AppColors.redcolor3,
                fontSize: 20,
               // fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: Text("For any queries or help"),
            trailing: RaisedButton(
              //  padding: EdgeInsets.only(right: 20, left: 20),
              //minWidth: 20,
              //// shape: Border.all(width: 2.0),
              shape: StadiumBorder(),
              color: AppColors.segcolor4,

              onPressed: () {
                Navigator.push(context, SlideTopRoute(page: Login()));
              },
              child: Text("Call Us",
                  style: TextStyle(
                    fontSize: 15,
                    color: Colors.white,
                  )),

              //textColor: Colors.blue,
            ),
          ),
        ),
        Container(
          height: 1,
          color: Colors.black12,
        ),
        Container(
          padding: EdgeInsets.only(top: 15, left: 15, bottom: 15),
          child: Text("Mail us at info@porter.in",
              style: TextStyle(
                fontSize: 20,
                color: AppColors.redcolor3,
              )),
        ),
        Container(
          height: 4,
          color: Colors.black12,
        ),
        Container(
          padding: EdgeInsets.only(left: 15, top: 10, bottom: 10),
          child: Text("App version v5.17.0",
              style: TextStyle(color: Colors.black38)),
        ),
        Container(
          height: 1,
          color: Colors.black26,
        ),
        Container(
          padding: EdgeInsets.only(left: 15, top: 10, bottom: 10),
          child: Text("LOGOUT",
              style: TextStyle(
                fontSize: 18,
                color: AppColors.redcolor3,
              )),
        ),
        Container(
          height: 1,
          color: Colors.black45,
        )
      ])),
    ));
  }
}
