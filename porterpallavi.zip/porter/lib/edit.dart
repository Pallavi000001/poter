import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:porter/color/AppColors.dart';

class Edit extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return Editt();
  }
}
class Editt extends State<Edit> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
        child: Scaffold(
        appBar: AppBar(
           iconTheme: IconThemeData(
             color:AppColors.redcolor3,
           ),
        backgroundColor: Colors.white,
        actions:<Widget>[
          Container(
            child: FlatButton(
              padding: EdgeInsets.only(right: 15,left: 10),
              minWidth: 20,
              //// shape: Border.all(width: 2.0),
              shape: StadiumBorder(),
              color: Colors.white,

              onPressed: (){
                //   Navigator.push(context, Signup);
              },
              child: Text("Save",style: TextStyle(fontSize: 20,color:AppColors.redcolor3,)), // textColor: Colors.blue,
            ),
          ),
        ]

        ),
          body: Container(
            padding: EdgeInsets.only(left:15),
            color: Colors.black12,
          child: ListView(
            children: [
              Container(
                padding: EdgeInsets.only(left:15,top: 15,bottom: 10),
              child: Text("Mobile number",
            style:TextStyle(
                 fontSize: 15,
                color: Colors.black54,

              ),
              )
              ),
              Container(
                child: Row(
                 // crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                        padding: EdgeInsets.only(left:15,right: 8),
                        child: Text("7669023456",
                          style:TextStyle(
                             fontSize: 20,
                            color: Colors.black,
                          ),
                        )
                    ),
                    Container(
                        child: Text("Cannot be changed.",
                          style:TextStyle(
                            fontSize: 15,
                            color: Colors.black54,
                          ),
                        )
                    ),
                  ],
                ),
              ),
              Container(
                padding:EdgeInsets.only(top: 20,right: 10),
                child:Card(
                  elevation: 60,
                    color: Colors.white,
                  child:InkWell(
                  // crossAxisAlignment: CrossAxisAlignment.start,
                  // children: [
               child: Container(
                 child:Column(
                   crossAxisAlignment: CrossAxisAlignment.start,
                   children: [
                     Container(
                    padding: EdgeInsets.only(top: 20,bottom: 10,left: 15),
                  child: Text("Pallavi",
                    style:TextStyle(
                      fontSize: 20,
                      color: Colors.black,
                    ),
                  )
              ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                        height: 1,
                        color: Colors.black26,
                    ),
                      ),
                    Container(
                        padding: EdgeInsets.only(top: 20,bottom: 10,left: 15),
                        child: Text("kumari",
                          style:TextStyle(
                            fontSize: 20,
                            color: Colors.black,
                          ),
                        )
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        padding: EdgeInsets.only(left: 10,right: 10),
                        height: 1,
                        color: Colors.black26,
                      ),
                    ),
                    Container(
                        padding: EdgeInsets.only(top: 20,bottom: 10,left: 15),
                        child: Text("plvkmri05@gmail.com",
                          style:TextStyle(
                            fontSize: 20,
                            color: Colors.black,
                          ),
                        )
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        padding: EdgeInsets.only(left: 10,right: 10),
                        height: 1,
                        color: Colors.black26,
                      ),
                    ),
                    Container(
                      child: ListTile(
                        title: Text("GST Details",
                            style:TextStyle(
                          fontSize: 20,
                                   color: Colors.black,
                               ),
                        ),
                        subtitle:  Text(" Not available",
                                style:TextStyle(
                                  fontSize: 18,
                                  color: AppColors.redcolor3,
                                ),
                      ),
                        trailing: Icon(Icons.arrow_drop_down,
                        color: AppColors.redcolor3,
                        ),
                    )


                 )
                      ]
               )

                  ),
          ),
        ),),
          ]
        )
    )
    )
    );

  }
}