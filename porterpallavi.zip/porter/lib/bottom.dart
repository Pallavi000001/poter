import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:location/location.dart';
import 'package:porter/Account.dart';
import 'package:porter/color/AppColors.dart';
import 'package:porter/order.dart';
import 'package:porter/payment.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'package:porter/home.dart';


class Bottom extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return Bottome();
  }
}

class Bottome extends State<Bottom> {

  Widget page = Homee();
  var indexedpage = 0;

  changeNav(index) async {
    if (index == 0) {
      setState(() {
        page = Homee();
        indexedpage = index;
      });
    }
    if (index == 1) {
      setState(() {
        page = Order();
        indexedpage = index;
      });
    }
    if (index == 2) {
      setState(() {
        page = Payment();
        indexedpage = index;
      });
    }
    if (index == 3) {
      setState(() {
        page = Account();
        indexedpage = index;
      });
    }
  }
    @override
    void initState() {
      // TODO: implement initState
      super.initState();
    }

    @override
    Widget build(BuildContext context) {
      // TODO: implement build
      return
        SafeArea(
        child: Scaffold(
          body: page,
          // floatingActionButton: FloatingActionButton.extended(
          //   onPressed: _goToTheLake,
          //   label: Text('To the lake!'),
          //   icon: Icon(Icons.directions_boat),
          // ),
          bottomNavigationBar: Container(
            height: 100,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Container(
                  child: Column(
                    children: [
                      Container(
                        child: IconButton(
                          onPressed: () {
                            changeNav(0);
                          },
                          icon: Icon(
                            Icons.home,
                            color: indexedpage == 0 ? AppColors.segcolor4 : Colors
                                .black,
                          ),
                        ),
                      ),
                      Container(
                        child: Text(
                          "Book Now",
                          style: TextStyle(
                              color: indexedpage == 0 ? AppColors.redcolor3 : Colors
                                  .black
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  child: Column(children: [
                    Container(
                      child: IconButton(
                        onPressed: () {
                          changeNav(1);
                        },
                        icon: Icon(
                          Icons.border_bottom_sharp,
                          color: indexedpage == 1 ? AppColors.segcolor4 : Colors.black,
                        ),
                      ),
                    ),
                    Container(
                      child: Text(
                        "Order",
                        style: TextStyle(
                            color: indexedpage == 1 ? AppColors.redcolor3: Colors.black
                        ),
                      ),
                    ),
                  ]),
                ),
                Container(
                  child: Column(children: [
                    Container(
                      child: IconButton(
                        onPressed: () {
                          changeNav(2);

                        },
                        icon: Icon(
                            Icons.payment_outlined,
                            color: indexedpage == 2 ? AppColors.segcolor4  : Colors.black

                        ),
                      ),
                    ),
                    Container(
                      child: Text("payment",
                        style: TextStyle(
                            color: indexedpage == 2 ? AppColors.redcolor3 : Colors.black

                        ),
                      ),

                    ),
                  ]),
                ),
                Container(
                  child: Column(children: [
                    Container(
                      child: IconButton(
                        onPressed: () {
                          changeNav(3);
                        },
                        icon: Icon(
                          Icons.account_box_outlined,
                          color: indexedpage == 3 ? AppColors.segcolor4  : Colors.black,
                        ),
                      ),
                    ),
                    Container(
                      child: Text("Account",
                        style: TextStyle(
                            color: indexedpage == 3 ?AppColors.redcolor3 : Colors.black
                        ),),
                    ),
                  ]),
                ),
              ],
            ),
          ),
        ),
      );
    }
  }
