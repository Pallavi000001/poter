import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'package:porter/Drop.dart';
import 'package:porter/color/AppColors.dart';
import 'package:porter/gold.dart';
import 'package:porter/offer.dart';
import 'package:porter/selectcity.dart';

import 'navanimator/navianimator.dart';

class Homee extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return Homeee();
  }
}
class Homeee extends State<Homee> {



  Location location = new Location();
  bool _serviceEnabled;
  PermissionStatus _permissionGranted;
  LocationData _locationData;
  var lat = 0.0;
  var lng = 0.0;
  getLocation() async{

    _permissionGranted = await location.hasPermission();
    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != PermissionStatus.granted) {
      }
    }

    _serviceEnabled = await location.serviceEnabled();
    if (!_serviceEnabled) {
      _serviceEnabled = await location.requestService();

    }else{

      _locationData = await location.getLocation();
      setState(() {
        lat = _locationData.latitude;
        lng = _locationData.longitude;
        print(lat);
      });
      if (!_serviceEnabled) {
        return;
      }
    }
  }

  Completer<GoogleMapController> _controller = Completer();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getLocation();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
        child: Scaffold(
            body: Container(
              // height: 200,
              child: lat ==0.0?Container():Stack(
                children: [
                  GoogleMap(
                    // mapType: MapType.normal,
                    // polylines: poly,
                    initialCameraPosition: CameraPosition(
                        target: LatLng(lat, lng), zoom: 15.0),
                    onMapCreated: (GoogleMapController controller) {
                      _controller.complete(controller);
                    },
                    compassEnabled: true,
                    // mapToolbarEnabled: true,
                    // zoomGesturesEnabled: true,
                    myLocationButtonEnabled: true,
                    zoomControlsEnabled: false,

                    // circles: circles,
                    myLocationEnabled: true,
                    padding: EdgeInsets.only(
                      top: MediaQuery.of(context).size.height/2
                    ),
                    // markers: Set.from(allMarks),
                    onCameraIdle: () {
                      // print(_lastMapPosition);
                      // getCurrentLocation(_lastMapPosition.latitude,
                      //     _lastMapPosition.longitude);
                    },
                    onCameraMove: (CameraPosition position) {
                      // print(position.target);
                      setState(() {
                        // _lastMapPosition = position.target;
                        lat = position.target.latitude;
                        lng = position.target.longitude;
                      });
                      // getCurrentLocation(
                      //     _lastMapPosition.latitude, _lastMapPosition.longitude);
                    },
                  ),
                  Positioned(
                    right: 10,
                    top: 10,
                    child: InkWell(
                      onTap: (){
                        Navigator.push(context, SlideTopRoute(page: Gold()));
                      },
                      child: Container(
                        height: 40,
                        width: 100,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.black,
                          image: DecorationImage(
                              image: NetworkImage("https://www.deviantart.com/papillonstudio/art/Trophy-Icon-567426146"
                              )

                          )
                        ),

                        child: Row(
                          children: [ 
                            Container(
                               padding: EdgeInsets.only(left: 4,right: 7),
                              height: 28,
                             // width: 150,
                              child: Image.asset("assets/icon1.png"),
                            ),

                            Text("Gold",
                                style:TextStyle(
                                fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color:AppColors.segcolor4
                                )
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  // Positioned(
                  //   right: 10,
                  //   bottom: 10,
                  //   left: 10,
                  //   child: InkWell(
                  //     onTap: (){
                  //       Navigator.push(context, SlideTopRoute(page:City()));
                  //     },
                  //     child: Container(
                  //       height: 40,
                  //       width: 200,
                  //       decoration: BoxDecoration(
                  //           borderRadius: BorderRadius.circular(10),
                  //           color: Colors.white,
                  //           // image: DecorationImage(
                  //           //     image: NetworkImage("https://www.deviantart.com/papillonstudio/art/Trophy-Icon-567426146"
                  //           //     )
                  //
                  //           ),
                  //
                  //       child: Row(
                  //         mainAxisAlignment: MainAxisAlignment.start,
                  //         children: [
                  //           Container(
                  //             padding: EdgeInsets.only(left: 4,right: 7),
                  //             height: 28,
                  //             // width: 150,
                  //             child: Image.asset("assets/home.webp",
                  //             )
                  //             ),
                  //           Text("Packers & Movers.",
                  //               style:TextStyle(
                  //                   fontSize: 15,
                  //                   fontWeight: FontWeight.bold,
                  //                   color:AppColors.redcolor3
                  //               )
                  //           ),
                  //           Text("full fledged shifting services",
                  //               style:TextStyle(
                  //                   fontSize: 15,
                  //                   //fontWeight: FontWeight.bold,
                  //                   color: Colors.black
                  //               )
                  //           )
                  //         ],
                  //       ),
                  //     ),
                  //   ),
                  // ),
                  Positioned(
                    right: 10,
                    bottom: 30,
                    left: 10,
                    child: InkWell(
                      onTap: (){
                        Navigator.push(context, SlideTopRoute(page: Drop()));
                      },
                      child: Container(
                        height: 30,
                        width: 200,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.white,
                          // image: DecorationImage(
                          //     image: NetworkImage("https://www.deviantart.com/papillonstudio/art/Trophy-Icon-567426146"
                          //     )

                        ),

                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Container(
                                padding: EdgeInsets.only(left: 4,right: 7),
                                height: 18,
                                // width: 150,
                                child: Image.asset("assets/searc1.png",
                                )
                            ),
                            Text(" Where  is  your ",
                                style:TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black
                                )
                            ),
                            Text(" Drop ?",
                                style:TextStyle(
                                    fontSize: 20,
                                    //fontWeight: FontWeight.bold,
                                    color:AppColors.redcolor3
                                )
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                  // Positioned(
                  //  // top: 200,
                  //  // left: 300,
                  //     bottom: 120,
                  //     right: 10,
                  //   child: Column(
                  //     children: [
                  //       InkWell(
                  //         onTap: (){
                  //           getLocation();
                  //         },
                  //         child: Container(
                  //           height: 40,
                  //           width: 40,
                  //           decoration: BoxDecoration(
                  //             borderRadius: BorderRadius.circular(2),
                  //             color: Colors.white,
                  //
                  //           ),
                  //           child: Icon(Icons.my_location,size: 30,),
                  //         ),
                  //       )
                  //     ],
                  //   ),
                  // ),
                  Positioned(
                    top: 0,
                    left: 0,
                    bottom:35,
                    right:0,

                            child: Container(
                              child: SizedBox(
                                height: 30,
                                width: 30,
                                child: Transform.scale(
                                  scale: 0.08,
                                  child: Image(
                                    image: AssetImage("assets/pin.png"),
                                  ),
                                ),
                              ),
                            ),
                  ),
                ],
              ),
            )
        )
    );
  }
}