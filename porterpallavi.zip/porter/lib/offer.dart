import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Offer extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return Offerr();
  }
}
class Offerr extends State<Offer> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
        child: Scaffold(
body: Container(
  color: Colors.black38,
  padding: EdgeInsets.only(top:10,bottom: 10,left: 10,right: 10),
  child: ListView(
    children: [
             Container(
               padding: EdgeInsets.only(top:20,bottom: 20,left: 20,right: 20),
               color: Colors.white,
               child:Column(
                 crossAxisAlignment: CrossAxisAlignment.start,
  children: [
    Container(
              width: MediaQuery.of(context).size.width,
              child: Image.asset("assets/p1.jpg"),
            ),
          Container(
            padding: EdgeInsets.only(top: 10),
            child: Text("join poter Gold to save more!",
            style:TextStyle(
                fontSize: 20,
              color: Colors.black
            )
            ),
          ),
      Container(
        padding: EdgeInsets.only(top: 10),
        child: Text("join Porter Gold to save much more",
            style:TextStyle(
                fontSize: 15,
                color: Colors.black54
            )
        ),
      ),
        ])),
          Container(
            height: 10,
            color: Colors.grey,
          ),
          Container(
            padding: EdgeInsets.only(top:20,bottom: 20,left: 20,right: 20),
            color: Colors.white,
            child:Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  child: Image.asset("assets/k1.jpg"),
                ),
                Container(
                   padding: EdgeInsets.only(top: 10),
                  child: Text("Do you see Porter driven words?",
                      style:TextStyle(
                          fontSize: 20,
                          color: Colors.black
                      )
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(top: 10),
                  child: Text("Click here to join the game!",
                      style:TextStyle(
                          fontSize: 15,
                          color: Colors.black54
                      )
                  ),
                ),
              ],
            ),
),
      Container(
        height: 10,
        color: Colors.grey,
      ),
      Container(
        padding: EdgeInsets.only(top:20,bottom: 20,left: 20,right: 20),
        color: Colors.white,
        child:Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              child: Image.asset("assets/po.jpg"),
            ),
            Container(
              padding: EdgeInsets.only(top: 10),
              child: Text("Connect with Porter to get updates!",
                  style:TextStyle(
                      fontSize: 20,
                      color: Colors.black
                  )
              ),
            ),
            Container(
              padding: EdgeInsets.only(top: 10),
              child: Text("Follow for speedier updates",
                  style:TextStyle(
                      fontSize: 15,
                      color: Colors.black54
                  )
              ),
            ),
          ],
        ),
      ),
      ]  )
    )
    ),
    );
  }
}