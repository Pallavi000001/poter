import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:porter/color/AppColors.dart';

import 'double page.dart';

class Order extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return Ordere();
  }
}
class Ordere extends State<Order> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
      child: Scaffold(
        body: Container(

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: EdgeInsets.only(top: 30,left: 15),
                child: Text("All orders",
                style:TextStyle(
                  fontSize: 30,
                  color: AppColors.redcolor3,

                )
                ),
              ),
              Center(
                child: Container(
                  padding: EdgeInsets.only(top: 100,right: 40),
                  child:Image.asset("assets/ici1.png")
                ),
              ),
              Center(

                child: Container(
                   padding: EdgeInsets.only(top: 70),
                  child: Text("You have no order",
                     style:TextStyle(
                          fontSize: 18
                     )
                      )
                  ),
              ),
                Center(
                  child: Container(
                   // width: MediaQuery.of(context).size.width,
                      padding:EdgeInsets.only(top: 30) ,
                    // child: FlatButton(
                    //   onPressed: (){},
                    //   shape: Border.all(width: 2.0,Colors.black),
                    // ),
                    child: FlatButton(
                      minWidth: 300,
                      shape: Border.all(width: 2.0),
                       color: Colors.white,

                      onPressed: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>TopSnapSheetExamplee()));
                      },
                      child: Text("Book Now",style: TextStyle(fontSize: 20,color: AppColors.segcolor4,))
                      ,
                      // textColor: Colors.blue,

                    ),



                  ),
                ),

            ],
          ),
        ),
      ),
    );
  }
}