import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Gold extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return Golde();
  }
}
class Golde extends State<Gold> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
        child: Scaffold(
        appBar: AppBar(
        backgroundColor: Colors.black,
        title:Text("porter Gold",
          style: new TextStyle(
            fontWeight: FontWeight.bold,
            // color: Colors.blue.shade600,
            fontSize: 20,
          ),
    ),
        ),
          body: Container(
            color:Colors.black,
            child: ListView(children: [
                Center(
            child: Container(
                      padding: EdgeInsets.only(top: 70),
                      child: Text("introducing",
                        style:TextStyle(
                            fontSize: 20,
                          color: Colors.orangeAccent

                      )
                  ),
                ),
                ),
              Center(
                child: Container(
                  padding: EdgeInsets.only(top: 10),
                  height: 130,
                  width: 150,
                  child: Image.asset("assets/icon1.png"),
                ),
              ),
              Center(
                child: Container(
                  padding: EdgeInsets.only(top: 10, bottom:30),
                  child: Text("PORTER GOLD",
                      style:TextStyle(
                          fontSize: 25,
                          fontWeight: FontWeight.bold,
                          color: Colors.orangeAccent

                      )
                  ),
                ),
              ),
              Container(
                padding:EdgeInsets.only(top: 20) ,
                height: 1,
                    color: Colors.orangeAccent
                  ),
              Container(
                child: Row(
                  children: [
                    Container(
                      child: IconButton(
                        onPressed: (){},
                        icon: Icon(Icons.tag,
                          color: Colors.orangeAccent,
                        ),
                      )
                    ),
                    Container(
                      padding: EdgeInsets.only(left: 10),
                      child: Text("Discounted fares for you orders",
                          style:TextStyle(
                          color: Colors.orangeAccent,
                          ),
                      ),
                    )
                  ],
                ),
              ),
              Container(
               height: 1,
                    color: Colors.orangeAccent,
              ),
              Container(
                child: Row(
                  children: [
                    Container(
                        child: IconButton(
                          onPressed: (){},
                          icon: Icon(Icons.nature_people,
                            color: Colors.orangeAccent,
                          ),
                        )
                    ),
                    Container(
                      padding: EdgeInsets.only(left: 10),
                      child: Text("Discounted not available on 2 wheeler",
                        style:TextStyle(
                          color: Colors.orangeAccent,
                        ),
                      ),
                    )
                  ],
                ),
              ),
              Container(
                height: 1,
                color: Colors.orangeAccent,
              ),
              Center(
                child: Container(
                  padding: EdgeInsets.only(bottom: 10,top:80),
                  child: Text("25%Discount upto₹100",
                  style:TextStyle(
                    fontSize: 20,
                      color: Colors.white,
                  )
                  ),
                ),
              ),
              Center(
                child: Container(
                  child: Text("on 10 Orders",
                      style:TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                      )
                  ),
                ),
              ),
              Center(
                child: Container(
                  padding: EdgeInsets.only(bottom: 20),
                  child: Text("Valid for 30 days",
                      style:TextStyle(
                        fontSize: 10,
                        color: Colors.white,
                      )
                  ),
                ),
              ),
              Container(

              )
              ]
            ),
          ),


        )
    );
  }
}