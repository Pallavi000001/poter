import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:custom_splash/custom_splash.dart';

import 'bottom.dart';
import 'navanimator/navianimator.dart';

class SplitScreen extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return SplitScreenn ();
  }
}
class SplitScreenn extends State<SplitScreen> {

//   redirectAfter() async{
//     new Future.delayed(Duration(seconds: 5),(){
//       Navigator.of(context).pushAndRemoveUntil(
//           SlideTopRoute(page: Bottom()), (Route<dynamic> route) => false);
// // Navigator.push(context, SlideTopRoute(page: MainpagePage(pageview: 0,)));
//     });
//   }

  @override
  void initState(){
    super.initState();
 //   redirectAfter();
  }
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
            body:CustomSplash(
              imagePath: 'assets/vgo.png',
              backGroundColor: Colors.black,
              animationEffect: 'zoom-in',
              home: Bottom(),
              duration: 2500,
              type: CustomSplashType.StaticDuration,
            )
        );


  }
}