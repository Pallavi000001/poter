import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:porter/color/AppColors.dart';

class Veri extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return Verii();
  }
}

class Verii extends State<Veri> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.black),
        backgroundColor: Colors.white,
        title: Text(
          "Paytm OTP verification",
          style: new TextStyle(
            fontWeight: FontWeight.bold,
            color: AppColors.redcolor3,
            fontSize: 20,
          ),
        ),
      ),
      body: Container(
        child:
        Column(
         // crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Center(
              child:
              Container(


                child: Column(
                    crossAxisAlignment:CrossAxisAlignment.center,
                    children: <Widget>[

                  Padding(
                    padding: EdgeInsets.only(top: 10,left: 10,right: 10),
                    child:
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                              border: Border.all(color: Colors.black12)),
                          child:  Container(
                            //width: 20,
                            //color: Colors.yellow,
                            //height: 50,

                            child: TextField(
                              //controller: category_description,
                              textAlign: TextAlign.center,
                              decoration: InputDecoration(
                                  border: InputBorder.none,

                                  hintText: "Enter OTP",

                                  hintStyle:
                                  TextStyle(color: Colors.grey[400]),

                                  counterText: ""),
                              keyboardType: TextInputType.number,
                              maxLength: 10,
                            ),
                          ),),
                    ),
                  ),
                ]),
              ),
            ),
            Container(
              padding: EdgeInsets.only(top: 30),
              width: 300,
            //  padding: EdgeInsets.only(left: 150),
              //width: MediaQuery.of(context).size.width,
              // width: MediaQuery.of(),
              child: FlatButton(
                padding: EdgeInsets.only(right: 10,left: 10,),
                minWidth: 30,
                //// shape: Border.all(width: 2.0),
                shape: StadiumBorder(),
                color: AppColors.segcolor4,

                onPressed: (){
                  //   Navigator.push(context, Signup);
                },
                child: Text("Verify",style: TextStyle(fontSize: 15,color: Colors.white,))
                ,
                // textColor: Colors.blue,

              ),



            ),
            Container(
              padding: EdgeInsets.only(top: 20),
              width: 300,
              //  padding: EdgeInsets.only(left: 150),
              //width: MediaQuery.of(context).size.width,
              // width: MediaQuery.of(),
              child: FlatButton(
                padding: EdgeInsets.only(right: 10,left: 10,),
                minWidth: 30,
                //// shape: Border.all(width: 2.0),
                shape: StadiumBorder(),
                color: Colors.white10,

                onPressed: (){
                  //   Navigator.push(context, Signup);
                },
                child: Text("Resend Otp",style: TextStyle(fontSize: 15,color:AppColors.redcolor3,))
                ,
                // textColor: Colors.blue,

              ),



            ),
          ],
        ),
      ),
    ));
  }
}
