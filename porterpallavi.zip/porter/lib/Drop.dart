

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:porter/DropAt.dart';
import 'package:porter/color/AppColors.dart';

class Drop extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return Dropp();
  }
}

class Dropp extends State<Drop> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor:AppColors.redcolor3,
          iconTheme: IconThemeData(color: Colors.white),
          title: Text(
            "Enter Drop location",
            style: new TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.white,
              fontSize: 20,
            ),
          ),
        ),
        body: Container(
          padding: EdgeInsets.only(top: 30),
          child: ListView(children: [
            //   Container(
            //     //height: 30,
            // child:Row(
            //   mainAxisAlignment: MainAxisAlignment.start,
            // children:[
            //   Padding(
            //     padding: const EdgeInsets.all(8.0),
            //     child: Container(
            //       height:20,
            //       width: 10,
            //       child: Image.asset("assets/icon11.html"),
            //     ),
            //   ),

            Container(
              // height: 100,

              //color: Colors.white,

              child: Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10.0),
                    child: Container(
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            border: Border.all(color: Colors.black12)),
                        child: Row(
                          children: [
                            Container(
                              width: 250,
                              //height: 50,

                              child: TextField(
                                autofocus: true,
                                //controller: category_description,
                                decoration: InputDecoration(
                                    border: InputBorder.none,
                                    hintText: "Search drop location",
                                    hintStyle:
                                        TextStyle(color: Colors.grey[400]),
                                    contentPadding: EdgeInsets.only(
                                      left: 10,
                                    ),
                                    counterText: ""),
                                keyboardType: TextInputType.text,
                                maxLength: 10,
                              ),
                            ),
                          ],
                        )),
                  ),
                  SizedBox(
                    height: 10.0,
                  ),
                  // Container(
                  //   padding: EdgeInsets.only(bottom: 10),
                  //   //color: Colors.black26,
                  //   // width: 200,
                  //   child: Text("Or",style: TextStyle(
                  //
                  //   ),),
                  // ),
                  // Container(
                  //   child: ListView.builder(
                  //     physics: NeverScrollableScrollPhysics(),
                  //     shrinkWrap: true,
                  //     itemCount: 3,
                  //     itemBuilder: (context, i){
                  //       return Container(
                  //         // height: 260,
                  //         padding: EdgeInsets.only(bottom: 1),
                  //         child: Container(
                  //           color: Colors.white,
                  //           padding:EdgeInsets.only(
                  //               left: 10,
                  //               right: 5,
                  //               top: 0,
                  //               bottom: 0
                  //           ) ,
                  //           width: MediaQuery.of(context).size.width,
                  //           child: Stack(
                  //             children: [
                  //               Container(
                  //                 child: Positioned(
                  //
                  //                   child: Container(
                  //                     padding: EdgeInsets.only(
                  //                       top: 1,
                  //                     ),
                  //                     child: Column(
                  //                       children: [
                  //                         Container(
                  //                           padding: EdgeInsets.only(top: 10,bottom: 10),
                  //                           child: Row(
                  //                             children: [
                  //
                  //                               Container(
                  //                                 height: 20,
                  //                                 width: 20,
                  //                                 //color:Colors.green,
                  //                                 child: new Radio(
                  //                                   value: 0,
                  //                                   groupValue: 0,
                  //                                   onChanged: (value) => 0,
                  //
                  //                                 ),
                  //
                  //                               ),
                  //                               Container(
                  //
                  //
                  //                                 padding: EdgeInsets.only(
                  //                                     left: 10,
                  //                                     right: 10,
                  //                                     top: 0),
                  //
                  //                                 child: Text("Raman Kumar",
                  //                                   style: TextStyle(
                  //                                       fontSize: 14,
                  //                                       fontWeight: FontWeight.w600,
                  //                                       color: Colors.black
                  //                                   ),),
                  //
                  //
                  //
                  //
                  //
                  //
                  //                               ),
                  //                               Container(
                  //                                 child: Text(""),
                  //                                 alignment: Alignment.topLeft,
                  //                               )
                  //
                  //                             ],
                  //                           ),
                  //                         ),
                  //                         Container(
                  //                           padding: EdgeInsets.only(left: 28,bottom: 10),
                  //                           child: Text("Som bazar noida 45,UP"),
                  //                           alignment: Alignment.topLeft,
                  //
                  //                         )
                  //                       ],
                  //                     ),
                  //
                  //
                  //
                  //
                  //                   ),
                  //
                  //
                  //                 ),
                  //               ),
                  //
                  //
                  //             ],
                  //           ),
                  //         ),
                  //
                  //
                  //
                  //
                  //       );
                  //     },
                  //   ),
                  // ),
                ],
              ),
            ),
            Container(
              child: Row(
                children: <Widget>[
                  Radio(
                    groupValue: 'Have Multiple Stops?',
                    value: 'Have Multiple Stops?',
                    // groupValue: _radioValue,
                    // onChanged: radioButtonChanges,
                  ),
                  Text(
                    "Have Multiple Stops?",
                  ),
                ],
              ),
              // Row(
              //   children: <Widget>[
              // Radio(
              // value: 'Female',
              //   // groupValue: _radioValue,
              //   // onChanged: radioButtonChanges,
              // ),
            ),
            Container(
              //padding: EdgeInsets.only(bottom: 10),
              height: 9,
              color: Colors.black26,
            ),
            Container(
              child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: 8,
                  itemBuilder: (BuildContext context, int i) {
                    return Container(
                      height: 60,
                      child:
                      InkWell(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>Dropat()));
                        },
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: EdgeInsets.only(left: 20, top: 10),
                              child: Text("Noida",
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                  )),
                            ),
                            Container(
                              padding:
                                  EdgeInsets.only(left: 20, top: 5, bottom: 10),
                              child: Text("Utter Pradesh ,India"),
                            ),
                            Container(
                              height: 1,
                              color: Colors.black26,
                            ),
                          ],
                        ),
                      ),
                    );
                  }),
            )
          ]),
        ),
      ),
    );
  }
}
