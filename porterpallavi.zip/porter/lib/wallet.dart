import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Wallet extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return Wallett();
  }
}
class Wallett extends State<Wallet> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
      child: Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.black),
        backgroundColor: Colors.white,
      title:Text("Payment",
        style: new TextStyle(
          fontWeight: FontWeight.bold,
          color: Colors.black,
          fontSize: 20,
        ),
      ),
    ),
    body: Container(
    color:Colors.white,
    child: ListView(children: [
      Container(
padding: EdgeInsets.only(top: 20),
        child: ListTile(
          leading:  Image.asset("assets/Paytm1.png",
              height:60,
            width: 60,
          ),
          title: Text("Go Cashless",
          style:TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18
          )
          ),
          subtitle: Text("pay for Porter trips with paytem wallet",
          style:TextStyle(
              color: Colors.black54
          )
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          padding: EdgeInsets.only(top: 10),
          width: 300,
          //  padding: EdgeInsets.only(left: 150),
          //width: MediaQuery.of(context).size.width,
          // width: MediaQuery.of(),
          child: FlatButton(
            padding: EdgeInsets.only(right: 30,left: 30,),
            minWidth: 30,
            //// shape: Border.all(width: 2.0),
            shape: StadiumBorder(),
            color: Colors.blue,

            onPressed: (){
              //   Navigator.push(context, Signup);
            },
            child: Text("Connect paytm Wallet",style: TextStyle(fontSize: 15,color: Colors.white,))
            ,
            // textColor: Colors.blue,

          ),



        ),
      ),
      Center(
        child: Container(
          child: Text("New Paytm account will be created if you don't have any"),
        ),
      )

    ])),
    )
    );}}