import 'package:flutter/material.dart';
import 'package:porter/color/AppColors.dart';
import 'package:snapping_sheet/snapping_sheet.dart';

class TopSnapSheetExamplee extends StatefulWidget {
  @override
  _TopSnapSheetExampleStatee createState() => _TopSnapSheetExampleStatee();
}

class _TopSnapSheetExampleStatee extends State<TopSnapSheetExamplee>
    with SingleTickerProviderStateMixin {
  var _controller = SnappingSheetController();
  AnimationController _arrowIconAnimationController;
  Animation<double> _arrowIconAnimation;

  double _moveAmount = 0.0;

  @override
  void initState() {
    super.initState();
    _arrowIconAnimationController =
        AnimationController(vsync: this, duration: Duration(seconds: 1));
    _arrowIconAnimation = Tween(begin: 0.0, end: 0.5).animate(CurvedAnimation(
        curve: Curves.elasticOut,
        reverseCurve: Curves.elasticIn,
        parent: _arrowIconAnimationController));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      // appBar: AppBar(
      //   title: Text('ListView example'),
      // ),
      body: SnappingSheet(
        sheetBelow: Container(color: Colors.white,
        child: ListView(
          children: [
            Container(
               padding: EdgeInsets.only(bottom: 20,left: 20,right: 20),
                color: Colors.white,
                child:Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      Container(
                        width: MediaQuery.of(context).size.width,
                        child: Image.asset("assets/p1.jpg"),
                      ),
                      Container(
                       padding: EdgeInsets.only(top: 10),
                        child: Text("join poter Gold to save more!",
                            style:TextStyle(
                                fontSize: 20,
                                color: Colors.black
                            )
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.only(top: 10),
                        child: Text("join Porter Gold to save much more",
                            style:TextStyle(
                                fontSize: 15,
                                color: Colors.black54
                            )
                        ),
                      ),
                    ])),
            Container(
              height: 10,
              color: Colors.grey,
            ),
            Container(
              padding: EdgeInsets.only(top:20,bottom: 20,left: 20,right: 20),
              color: Colors.white,
              child:Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width,
                    child: Image.asset("assets/k1.jpg"),
                  ),
                  Container(
                    padding: EdgeInsets.only(top: 10),
                    child: Text("Do you see Porter driven words?",
                        style:TextStyle(
                            fontSize: 20,
                            color: Colors.black
                        )
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.only(top: 10),
                    child: Text("Click here to join the game!",
                        style:TextStyle(
                            fontSize: 15,
                            color: Colors.black54
                        )
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 10,
              color: Colors.grey,
            ),
            Container(
              padding: EdgeInsets.only(top:20,bottom: 20,left: 20,right: 20),
              color: Colors.white,
              child:Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width,
                    child: Image.asset("assets/po.jpg"),
                  ),
                  Container(
                    padding: EdgeInsets.only(top: 10),
                    child: Text("Connect with Porter to get updates!",
                        style:TextStyle(
                            fontSize: 20,
                            color: Colors.black
                        )
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.only(top: 10),
                    child: Text("Follow for speedier updates",
                        style:TextStyle(
                            fontSize: 15,
                            color: Colors.black54
                        )
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        ),

        grabbing: Container(
          decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                    color: Colors.black26,
                    blurRadius: 10
                )
              ]
          ),
          child:Container(
    child:Row(
      mainAxisAlignment: MainAxisAlignment.center,
            children:[
              Container(
                child: Text("Offer",
                style: TextStyle(
                  color: AppColors.redcolor3,
                  fontSize: 18,
                  fontWeight: FontWeight.bold

                ),
                ),
              ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Center(
              child: Container(
//padding: EdgeInsets.only(left: 30),
                height: 5,
                width: 40,
                decoration: BoxDecoration(
                    color: AppColors.redcolor3,
                    borderRadius: BorderRadius.all(
                        Radius.circular(120)
                    )
                ),
              ),
            ),
        ),
          ]
    )
          ),
        ),
        grabbingHeight: 20,
        initSnapPosition: SnapPosition(positionPixel: 50,positionFactor: 100.0,),
        child: SafeArea(
          child: Container(
            color: Colors.black38,
            child: Container(
              color: Colors.red,
              child: Text(
                "Hello World",
                style: TextStyle(
                    color: Colors.black
                ),
              ),
            ),
          ),
        ),
        lockOverflowDrag: false,
      ),

    );
  }}