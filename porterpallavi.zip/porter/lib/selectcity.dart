import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class City extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return Cityy();
  }
}
class Cityy extends State<City> {

  var dropdownIndex = 0;

  changeMenu(i) async{
    setState(() {
      dropdownIndex = i;
    });
  }
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
      child: Scaffold(
      appBar: AppBar(
      backgroundColor: Colors.blueAccent,
      title:Text("Packers and Movers",
        style: new TextStyle(
          fontWeight: FontWeight.bold,
          color: Colors.white,
          fontSize: 20,
        ),
      ),
    ),
        body: Container(
      //padding: EdgeInsets.only(left: 20,right: 20,top: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 10,
            color: Colors.black26,
          ),
          Container(
            padding: EdgeInsets.only(left: 20,right: 20,top: 20),
            //color: Colors.black12,
      //height: 200,
            width: 300,
            //padding: EdgeInsets.only(left: 10),
          child:Text("Enter Location Details",
            style: TextStyle(
              fontWeight: FontWeight.bold,
                fontSize: 20,
                color:Colors.black
            ),
          )),
          Container(
           // height: 30,
            //swidth: 300,
            padding: EdgeInsets.only(left: 30.0,right: 20,top: 20),
            child: Column(
              children: [
                new Container(
                //  height: widget.height,
                 // padding: EdgeInsets.only(left: 20.0,right: 20),
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      side: BorderSide(
                          width: 0.8, style: BorderStyle.solid, color: Colors.black12),
                      borderRadius: BorderRadius.all(Radius.circular(10.0)),
                    ),
                  ),
                  child:DropdownButton(
                    iconSize: 30,
                    value: dropdownIndex,
                    onChanged: (val){
                      changeMenu(val);
                    },
                    hint:Text( "Select City",
                    ),
                    items: [
                      DropdownMenuItem(
                        child: Text("Mumbai"),
                        value: 0,
                      ),
                      DropdownMenuItem(
                        child: Text("Delhi"),
                        value: 1,
                      ),
                      DropdownMenuItem(
                        child: Text("bangalore"),
                        value: 2,
                      ),
                      DropdownMenuItem(
                        child: Text("pune"),
                        value: 3,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(
            height: 10,
            color: Colors.black26,
          ),
            Positioned(
            right: 0,
            top: 0,
            bottom: 0,
            left: 0,
            child: Row(
            children: [
              Container(
                padding: EdgeInsets.only(bottom: 80,top: 40),
                width:MediaQuery.of(context).size.width,

          //  padding: EdgeInsets.only(left: 4,right: 7),
   //height: 208,
     //width: 150,
    child: Image.asset("assets/map1.jpg"),
    ),

    ],
      ),
        ),
          Center(
            child: Container(
              height: 40,
              width:300,
             child: RaisedButton(
                  padding: EdgeInsets.only(right: 15, left: 15,top: 0),
                //minWidth: 20,
                //// shape: Border.all(width: 2.0),
                shape: StadiumBorder(),
                color: Colors.blue,

                onPressed: () {
               //   Navigator.push(context, SlideTopRoute(page: Offer()));
                },
                child: Text("Proceed",
                    style: TextStyle(
                      fontSize: 15,
                      color: Colors.white,
                    )),

                //textColor: Colors.blue,
              ),

              ),
          ),
        ]
        )

      )
    )
    );
  }
}
