import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:porter/color/AppColors.dart';
import 'package:porter/verification.dart';
import 'package:porter/wallet.dart';

import 'navanimator/navianimator.dart';

class Payment extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return Paymentt();
  }
}
class Paymentt extends State<Payment> {
  _SBottomSheetMenu()
  {
    showModalBottomSheet(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(0.0))),
        backgroundColor: Color(0xFFFf6f6f6),
        context: context,
        isScrollControlled: true,
        builder: (context) => Padding(
          padding: const EdgeInsets.symmetric(horizontal:5.7 ),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Container(

                  child: AppBar(

                    backgroundColor: Colors.white,
                    automaticallyImplyLeading: false,
                    title: Text("Add money"
                      ,style: TextStyle(
                          color: AppColors.redcolor3,
                      fontSize: 16
                      ),

                    ),
                    elevation: 0,
                    actions: [
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);

                        },
                        icon: Icon(
                          Icons.close,
                          color: AppColors.redcolor3,
                        ),
                      ),

                    ],
                    iconTheme: IconThemeData(

                        color: Colors.black
                    ),
                  ),
                ),
                Container(
                 // padding: (EdgeInsets.only(top: 10)),
                ),

                Container(
                  // height: 100,

                  //color: Colors.white,


                  child: Column(

                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10.0),
                        child: Container(


                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.all(Radius.circular(10)),
                                border: Border.all(
                                    color: Colors.black12
                                )

                            ),

                            child: Row(
                              children: [
                                Container(
                                  width: 250,
                                  //height: 50,

                                  child: TextField(
                                    autofocus: true,
                                    //controller: category_description,
                                    decoration: InputDecoration(
                                        border: InputBorder.none,
                                        hintText: "Enter amount",
                                        hintStyle: TextStyle(color: Colors.grey[400]
                                        ),
                                        contentPadding: EdgeInsets.only(
                                          left: 10,
                                        ),
                                        counterText: ""

                                    ),
                                    keyboardType: TextInputType.number,
                                    maxLength: 10,


                                  ),
                                ),

                              ],
                            )


                        ),
                      ),
                      SizedBox(
                        height: 10.0,
                      ),
                      Container(
                        padding: EdgeInsets.only(top: 10,bottom: 10),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                           // bottom: MediaQuery.of(context).viewInsets.bottom,
                            left: 15,
                            right: 15
                        ),

                        child:  InkWell(
                          onTap: (){

                          },
                          child: Container(
                            //padding: EdgeInsets.only(left: 50.0),
                            height: 40,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                    color: Colors.black
                                ),

                                color: Colors.white

                            ),



                            child:
                            Center(
                              child:
                              Text(
                                // loading == true ? "Loading.." :
                                "Proceed",
                                style: TextStyle(color: AppColors.redcolor3,
                                    fontWeight:FontWeight.bold ),
                              ),
                            ),
                          ),
                        ),

                      ),

                      SizedBox(height: 10),
                    ],
                  ),
                ),

              ],
            ),
          ),
        ));
  }
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
        child: Scaffold(
            body: Container(
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
          children: [
           Container(
             padding: EdgeInsets.only(left:15,top: 20,bottom: 10),

             child: Text("Payment",
             style:TextStyle(
               fontSize: 30
                   ,
               color: AppColors.redcolor3

        )
             ),

           ),
            Container(
              child: ListTile(

                    title: Text("proter credits",
                    style:TextStyle(
                      fontSize: 20,

                    )
                    ),

                 // width: MediaQuery.of(context).size.width,
                 // padding: EdgeInsets.only(left: 8),

                        subtitle: Text("Balance₹0"
        ),
                    //width: MediaQuery.of(context).size.width,
                    // width: MediaQuery.of(),
                    trailing: FlatButton(
                     padding: EdgeInsets.only(right: 10,left: 10),
                       minWidth: 20,
                     //// shape: Border.all(width: 2.0),
                      shape: StadiumBorder(),
                      color: AppColors.segcolor4,

                      onPressed: (){
                        _SBottomSheetMenu();
                        //   Navigator.push(context, Signup);
                      },
                      child: Text("Add Money",style: TextStyle(fontSize: 15,color: Colors.white,)),
                      // textColor: Colors.blue,
                    ),
              ),
            ),
            Container(
              //padding: EdgeInsets.only(left: 40,right: 40),
              height: 1,
              color: Colors.black54,

            ),
          Container(
                            child: Row(
                              children: [
                                Container(
                                  child:IconButton(
                                    onPressed: (){
                                      Navigator.push(context, SlideTopRoute(page: Wallet()));
                                    },
                                    icon:Icon(Icons.payment_outlined,
                                    color:AppColors.segcolor4
                                    )
                                  ),
                                ),
                                Container(
                                  child: Text("Paytm",
                                    style: TextStyle(
                                      color:AppColors.redcolor3,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                Container(
                                  child: Text(" Wallet",
                                    style: TextStyle(
                                      fontSize: 20,
                                      //fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                        Container(
                         // padding:EdgeInsets.only(top: 0),
                          //
                        // color: Colors.black,
                          transform: Matrix4.translationValues(0.0, -20.0, 0.0),
                        child:ListTile(
                          // contentPadding:EdgeInsets.only(top: 0) ,
                          title: Text("New paytm account will be created"),
                          subtitle: Text(
                              " if you don't have any"
                  ),
                    trailing: FlatButton(
                      padding: EdgeInsets.only(right: 10,left: 10),
                      minWidth: 20,
                      //// shape: Border.all(width: 2.0),
                      shape: StadiumBorder(),
                      color:AppColors.segcolor4,

                      onPressed: (){
                        Navigator.push(context, SlideTopRoute(page: Veri()));
                      },
                      child: Text("Link Wallet",style: TextStyle(fontSize: 15,color: Colors.white,))
                      ,
                      // textColor: Colors.blue,

                    ),

                  ),

              ),

            Container(
              transform: Matrix4.translationValues(0.0, -20.0, 0.0),
              padding: EdgeInsets.only(left: 40,right: 40,top: 20),
              height: 1,
              color: Colors.black54,),
      ]
        ),
    ),
    )
    );

  }
}