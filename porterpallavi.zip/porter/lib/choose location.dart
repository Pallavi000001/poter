import 'dart:async';
//import 'dart:html';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'package:snapping_sheet/snapping_sheet.dart';

import 'color/AppColors.dart';

class TopSnapSheetExample extends StatefulWidget {
  @override
  _TopSnapSheetExampleState createState() => _TopSnapSheetExampleState();
}

class _TopSnapSheetExampleState extends State<TopSnapSheetExample>
    with SingleTickerProviderStateMixin {
  var _controller = SnappingSheetController();
  Location location = new Location();
  bool _serviceEnabled;
  PermissionStatus _permissionGranted;
  LocationData _locationData;
  var lat = 0.0;
  var lng = 0.0;
  getLocation() async {
    _permissionGranted = await location.hasPermission();
    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != PermissionStatus.granted) {}
    }

    _serviceEnabled = await location.serviceEnabled();
    if (!_serviceEnabled) {
      _serviceEnabled = await location.requestService();
    } else {
      _locationData = await location.getLocation();
      setState(() {
        lat = _locationData.latitude;
        lng = _locationData.longitude;
        print(lat);
      });
      if (!_serviceEnabled) {
        return;
      }
    }
  }
  Completer<GoogleMapController> _controllers = Completer();
  AnimationController _arrowIconAnimationController;
  Animation<double> _arrowIconAnimation;
  double _moveAmount = 0.0;
  @override
  void initState() {
    super.initState();
    getLocation();
    _arrowIconAnimationController =
        AnimationController(vsync: this, duration: Duration(seconds: 1));
    _arrowIconAnimation = Tween(begin: 0.0, end: 0.5).animate(CurvedAnimation(
        curve: Curves.elasticOut,
        reverseCurve: Curves.elasticIn,
        parent: _arrowIconAnimationController));
  }
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child:Scaffold(
      body: SnappingSheet(
        sheetAbove:
            Container(
          color: Colors.white,
            //height: 10,

             child :Container(
               child:ListView(
               children:[
                 Container(
                   height: 20,
                     color: Colors.white,
                 ),
                 Container(
                   height: 130,
                   width: 200,

                   padding: EdgeInsets.only(top: 15),
                   child: ListView.builder(
                     scrollDirection: Axis.horizontal,
                     itemCount: 10,
                     itemBuilder: (context, i){
                       return Container(
                         width:120,
                         //24color: i == 0?Colors.black:i ==1?Colors.blue:i == 2?Colors.red:i == 3?Colors.black:Colors.blue,
                         child:Column(
                             children:[
                               Container(
                                   child: Text("Tata Ace",
                                     style: TextStyle(
                                         color: Colors.black87,
                                         fontWeight: FontWeight.bold
                                       //  fontSize: 20,
                                     ),
                                   )
                               ),
                               Container(
                                 padding: EdgeInsets.only(right: 5,bottom: 5),
                                 height: 60,
                                 child: Image.asset("assets/car5.png"),
                               ),
                               Container(
                                 padding: EdgeInsets.only(top:5,),
                                 child: Text("18 mins"),
                               ),
                               Container(
                                 child: Text("₹671.00!"),
                               )
                             ]
                         ),
                       );

                     },

                   ),
                 ),
                 Container(
                   height: 10,
                 ),
                 // Container(
                 //   height: 40,
                 //   child: Row(
                 //       mainAxisAlignment: MainAxisAlignment.spaceAround,
                 //       children:[
                 //         Container(
                 //           child: Text("Pickup contact",
                 //             style: TextStyle(
                 //                 fontSize: 18
                 //             ),
                 //           ),
                 //         ),
                 //         Container(
                 //           child: Row(
                 //             children: [
                 //               Container(
                 //                 child: Text("7667012345 ",
                 //                   style: TextStyle(
                 //                       color: Colors.deepOrange
                 //                   ),
                 //                 ),
                 //               ),
                 //               Container(
                 //                 height: 5,
                 //                 child: Image.asset("assets/blue2.jpg"),
                 //               ),
                 //               Container(
                 //                 child: Text(" pallavi kumari",
                 //                   style: TextStyle(
                 //                       color: Colors.deepOrange
                 //                   ),
                 //                 ),
                 //               )
                 //             ],
                 //           ),
                 //         )
                 //       ]
                 //   ),
                 // ),
                 // Container(
                 //   padding: EdgeInsets.only(top: 10),
                 //   height: 5,
                 //   color: Colors.orange.shade100
                 // ),

                 // Container(
                 //     child:RaisedButton(
                 //       shape: StadiumBorder(
                 //
                 //       ),
                 //       color: Colors.white,
                 //
                 //       onPressed: () {
                 //         //   Navigator.push(context, Signup);
                 //       },
                 //       child: Row(
                 //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                 //         children: [
                 //           Container(
                 //               child:Row(
                 //                   children: [
                 //                     Container(
                 //                       height: 30,
                 //                       child: Image.asset("assets/icon3.jpg"),
                 //                     ),
                 //                     Container(
                 //                       //   padding: EdgeInsets.only(left:),
                 //                       child: Text("Save 15% on this trip",
                 //                           style: TextStyle(
                 //                             fontSize: 15,
                 //                             color: Colors.black87,
                 //                           )),
                 //                     ),
                 //                   ]
                 //               )
                 //           ),
                 //           Container(
                 //             child:Row(
                 //                 children:[
                 //                   Container(
                 //                     //  padding: EdgeInsets.only(left:40),
                 //                     height: 30,
                 //                     child: Image.asset("assets/per.jpg"),
                 //                   ),
                 //                   Container(
                 //                       child:Text("Apply Coupon",
                 //                           style:TextStyle(
                 //                             fontSize: 18,
                 //                             color:Colors.redAccent,
                 //                           )
                 //                       )
                 //                   ),
                 //                 ]
                 //             ),
                 //           ),
                 //         ],
                 //       ),
                 //     )
                 // ),
                 // Center(
                 //   child: Container(
                 //       padding: EdgeInsets.only(top: 10),
                 //       child:RaisedButton(
                 //         shape: StadiumBorder(
                 //
                 //         ),
                 //         color: Colors.white,
                 //
                 //         onPressed: () {
                 //           //   Navigator.push(context, Signup);
                 //         },
                 //         child: Row(
                 //           children: [
                 //             Container(
                 //               height: 30,
                 //               child: Image.asset("assets/help1.jpg"),
                 //             ),
                 //             // Icon(
                 //             //   Icons.share,
                 //             //   color: Colors.white,
                 //             // ),
                 //             Container(
                 //               padding: EdgeInsets.only(left:10),
                 //               child: Text("Include Helper",
                 //                   style: TextStyle(
                 //                     fontSize: 15,
                 //                     color: Colors.black87,
                 //                   )),
                 //             ),
                 //             Container(
                 //               padding: EdgeInsets.only(left:10),
                 //               height: 30,
                 //               child: Image.asset("assets/new1.png"),
                 //             ),
                 //           ],
                 //         ),
                 //       )
                 //   ),
                 // ),

               ]
        ),
             ),
              // Container(
              // child:Column(
              //   children: [
              //     Container(
              //       child: RaisedButton(
              //       color:Colors.black54
              //       ),
              //     ),
//                   Container(
// // padding: EdgeInsets.only(left: 10),
//               child: ListView.builder(
//                 scrollDirection: Axis.horizontal,
//                 itemCount: 10,
//                 itemBuilder: (context, i){
//                   return Container(
//                     width:80,
//                     //24color: i == 0?Colors.black:i ==1?Colors.blue:i == 2?Colors.red:i == 3?Colors.black:Colors.blue,
//                       child:Column(
//                       children:[
//
//                       Container(
//                       child: Text("Tata Ace",
//                       style: TextStyle(
//                         fontWeight: FontWeight.bold
//                     //  fontSize: 20,
//                   ),
//                   )
//                   ),
//                   Container(
//                     height: 30,
//                   child: Image.asset("assets/car3.jpg"),
//                   ),
//                   Container(
//                   child: Text("....mins"),
//                   ),
//                   Container(
//                   child: Text("₹....!"),
//                   )
//                   ]
//                   ),
//                   );
//
//                 },
//               ),
//             ),
              //   ]
              // ),
           // )
        ),
        grabbing:
          Center(
            child: Container(
            decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                      color: Colors.black26,
                      blurRadius: 10
                  )
                ]
            ),

              child: Center(
                child: Container(
                  height: 5,
                  width: 40,
                  decoration: BoxDecoration(
                      color: Colors.black38,
                      borderRadius: BorderRadius.all(
                          Radius.circular(120)
                      )
                  ),
            ),
              ),
            ),
          ),
        grabbingHeight: 20,
        snapPositions: [
          SnapPosition(positionPixel: 560 )
        ],
        initSnapPosition: SnapPosition(positionPixel: 560,positionFactor: 100.0,),
        child: SafeArea(
          child: Container(
            child:Column(
    children: [
      Container(
        width: MediaQuery.of(context).size.width,
            color: Colors.black38,
            child: Container(
              child: lat == 0.0
                  ? Container()
                  : Stack(children: [
                GoogleMap(
                  // mapType: MapType.normal,
                  // polylines: poly,
                  initialCameraPosition:

                  CameraPosition(target: LatLng(lat, lng), zoom: 15.0),
                  onMapCreated: (GoogleMapController controller) {
                    _controllers.complete(controller);
                  },
                  compassEnabled: true,
                  //mapToolbarEnabled: false,
                  // zoomGesturesEnabled: true,
                  myLocationButtonEnabled: true,
                  zoomControlsEnabled: false,

                  // circles: circles,
                  myLocationEnabled: true,
                  padding: EdgeInsets.only(
                      top: MediaQuery.of(context).size.height / 2),
                  // markers: Set.from(allMarks),
                  onCameraIdle: () {
                    // print(_lastMapPosition);
                    // getCurrentLocation(_lastMapPosition.latitude,
                    //     _lastMapPosition.longitude);
                  },
                  onCameraMove: (CameraPosition position) {
                    // print(position.target);
                    setState(() {
                      // _lastMapPosition = position.target;
                      lat = position.target.latitude;
                      lng = position.target.longitude;
                    });
                    // getCurrentLocation(
                    //     _lastMapPosition.latitude, _lastMapPosition.longitude);
                  },
                ),
              ]),

              // child: Text(
              //   "Hello World",
              //   style: TextStyle(
              //       color: Colors.black
              //   ),
            //  ),
            ),
          ),
      Container(
        //height: 50,
        child: Column(
          children: [
            Container(
              height: 50,
                  child:RaisedButton(
                    shape: StadiumBorder(

                    ),
                    color: Colors.white,

                    onPressed: () {
                      //   Navigator.push(context, Signup);
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                            child:Row(
                                children: [
                                  Container(
                                    height: 30,
                                    child: Image.asset("assets/icon3.jpg"),
                                  ),
                                  Container(
                                    //   padding: EdgeInsets.only(left:),
                                    child: Text("Save 15% on this trip",
                                        style: TextStyle(
                                          fontSize: 15,
                                          color: Colors.black87,
                                        )),
                                  ),
                                ]
                            )
                        ),
                        Container(
                          child:Row(
                              children:[
                                Container(
                                  //  padding: EdgeInsets.only(left:40),
                                  height: 40,
                                  child: Image.asset("assets/per.jpg"),
                                ),
                                Container(
                                    child:Text("Apply Coupon",
                                        style:TextStyle(
                                          fontSize: 18,
                                          color:Colors.redAccent,
                                        )
                                    )
                                ),
                              ]
                          ),
                        ),
                      ],
                    ),
                  )),
            // Container(
            //   height: 20,
            //   child: Row(
            //       mainAxisAlignment: MainAxisAlignment.spaceAround,
            //       children:[
            //         Container(
            //           child: Text("Pickup contact",
            //             style: TextStyle(
            //                 fontSize: 18
            //             ),
            //           ),
            //         ),
            //         Container(
            //           child: Row(
            //             children: [
            //               Container(
            //                 child: Text("7667012345 ",
            //                   style: TextStyle(
            //                       color: Colors.deepOrange
            //                   ),
            //                 ),
            //               ),
            //               Container(
            //                 height: 5,
            //                 child: Image.asset("assets/blue2.jpg"),
            //               ),
            //               Container(
            //                 child: Text(" pallavi kumari",
            //                   style: TextStyle(
            //                       color: Colors.deepOrange
            //                   ),
            //                 ),
            //               )
            //             ],
            //           ),
            //         )
            //       ]
            //   ),
            // ),
            Center(
              child: Container(
                padding: EdgeInsets.only(top: 15),
               // height: 40,
                width: 300,
                child: FlatButton(
                //  padding: EdgeInsets.only(right: 30,left: 30,),
                 // minWidth: 30,
                  //// shape: Border.all(width: 2.0),
                  shape: StadiumBorder(),
                  color: AppColors.redcolor3,

                  onPressed: (){
                    //Navigator.push(context, MaterialPageRoute(builder: (context)=>TopSnapSheetExample()));
                  },
                  child: Text("Goods Types?",
                      style: TextStyle(fontSize: 18,color: Colors.white,))
                  ,
                  // textColor: Colors.blue,

                ),



              ),
            ),

          ],
        ),

      ),
    ]
    ),
          ),

        ),
       lockOverflowDrag: true,
      ),

        ),
    );
  }

  @override
  void dispose() {
    _arrowIconAnimationController.dispose();
    super.dispose();
  }
}
class SheetContent extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: ListView.builder(
        padding: EdgeInsets.all(20.0),
        itemCount: 50,
        itemBuilder: (context, index) {
          return Container(
            decoration: BoxDecoration(
                border: Border(
                    bottom:
                    BorderSide(color: Colors.grey.shade300, width: 1.0))),
            child: ListTile(
              leading: Icon(Icons.info),
              title: Text('List item $index'),
            ),
          );
        },
      ),
    );
  }
}
